"use client"

import type { Magazine } from "@/components/magazine-grid"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ShoppingCart, Pencil, Trash2, Eye, Download, Package } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useState } from "react"
import { PreviewDialog } from "@/components/preview-dialog"

interface MagazineCardProps {
  magazine: Magazine
  onEdit?: (magazine: Magazine) => void
  onDelete?: (id: string) => void
}

export function MagazineCard({ magazine, onEdit, onDelete }: MagazineCardProps) {
  const { addItem } = useCart()
  const { toast } = useToast()
  const [previewOpen, setPreviewOpen] = useState(false)

  const handleAddToCart = () => {
    if (magazine.stok <= 0) {
      toast({
        title: "Stok habis",
        description: `${magazine.nama} sedang tidak tersedia`,
        variant: "destructive",
      })
      return
    }

    addItem(magazine)
    toast({
      title: "Ditambahkan ke keranjang",
      description: `${magazine.nama} berhasil ditambahkan`,
    })
  }

  const handleDelete = () => {
    if (onDelete) {
      onDelete(magazine.id)
      toast({
        title: "Majalah dihapus",
        description: `${magazine.nama} telah dihapus dari koleksi`,
        variant: "destructive",
      })
    }
  }

  const coverImageSrc = magazine.coverImage || `https://placehold.co/400x533?text=${encodeURIComponent(magazine.nama)}`
  console.log("[v0] Rendering magazine card:", magazine.nama, "has coverImage:", !!magazine.coverImage)

  return (
    <>
      <Card className="group overflow-hidden hover:shadow-lg transition-shadow">
        <div className="aspect-[3/4] bg-muted relative overflow-hidden">
          <img
            src={coverImageSrc || "/placeholder.svg"}
            alt={`Cover majalah ${magazine.nama}`}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              console.error("[v0] Image failed to load for:", magazine.nama)
              const target = e.target as HTMLImageElement
              target.src = `https://placehold.co/400x533?text=${encodeURIComponent(magazine.nama)}`
            }}
          />
          {magazine.tipe === "gratis" && (
            <div className="absolute top-2 left-2 bg-green-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
              GRATIS
            </div>
          )}
          {magazine.stok <= 0 && (
            <div className="absolute top-2 left-2 bg-red-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
              HABIS
            </div>
          )}
          <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            {onEdit && (
              <Button size="icon" variant="secondary" className="h-8 w-8 shadow-md" onClick={() => onEdit(magazine)}>
                <Pencil className="h-4 w-4" />
              </Button>
            )}
            {onDelete && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button size="icon" variant="destructive" className="h-8 w-8 shadow-md">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Hapus Majalah?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Apakah Anda yakin ingin menghapus "{magazine.nama}"? Tindakan ini tidak dapat dibatalkan.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Batal</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete}>Hapus</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>

        <div className="p-4">
          <div className="mb-2">
            <span className="text-xs text-muted-foreground uppercase tracking-wide">{magazine.kategori}</span>
          </div>
          <h3 className="font-serif font-semibold text-lg mb-1">{magazine.nama}</h3>
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{magazine.judul}</p>

          <div className="flex items-center justify-between mb-3">
            <span className="font-semibold text-lg">
              {magazine.tipe === "gratis" ? "Gratis" : `Rp ${magazine.harga.toLocaleString("id-ID")}`}
            </span>
            <span className="text-xs text-muted-foreground">{magazine.totalPages} halaman</span>
          </div>

          <div className="flex items-center gap-2 mb-3 text-xs">
            <Package className="h-3 w-3 text-muted-foreground" />
            <span
              className={
                magazine.stok <= 10 && magazine.stok > 0 ? "text-orange-600 font-medium" : "text-muted-foreground"
              }
            >
              {magazine.stok <= 0
                ? "Stok habis"
                : magazine.stok <= 10
                  ? `Tersisa ${magazine.stok} edisi`
                  : `Stok: ${magazine.stok}`}
            </span>
          </div>

          <div className="flex gap-2">
            <Button onClick={() => setPreviewOpen(true)} variant="outline" size="sm" className="flex-1 gap-2">
              <Eye className="h-4 w-4" />
              Preview
            </Button>
            {magazine.tipe === "berbayar" ? (
              <Button onClick={handleAddToCart} size="sm" className="flex-1 gap-2" disabled={magazine.stok <= 0}>
                <ShoppingCart className="h-4 w-4" />
                {magazine.stok <= 0 ? "Habis" : "Beli"}
              </Button>
            ) : (
              <Button onClick={handleAddToCart} size="sm" className="flex-1 gap-2" disabled={magazine.stok <= 0}>
                <Download className="h-4 w-4" />
                {magazine.stok <= 0 ? "Habis" : "Unduh"}
              </Button>
            )}
          </div>
        </div>
      </Card>

      <PreviewDialog open={previewOpen} onOpenChange={setPreviewOpen} magazine={magazine} />
    </>
  )
}
