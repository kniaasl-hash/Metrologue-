export function Hero() {
  return (
    <section className="relative py-20 md:py-32 bg-gradient-to-b from-secondary/50 to-background overflow-hidden">
      <div className="absolute top-10 left-10 opacity-10">
        <img
          src="https://placehold.co/200x400?text=Ondel+ondel+Jakarta+traditional+puppet+mascot+with+colorful+costume+and+big+smile"
          alt="Ondel-ondel decoration"
          className="w-32 md:w-48 h-auto"
        />
      </div>
      <div className="absolute bottom-10 right-10 opacity-10">
        <img
          src="https://placehold.co/200x400?text=Ondel+ondel+Betawi+cultural+icon+with+traditional+attire+and+vibrant+colors"
          alt="Ondel-ondel decoration"
          className="w-32 md:w-48 h-auto"
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-balance text-primary">
            Metrologue E-Magazine
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 text-pretty">
            Platform majalah digital eksklusif dari J One TV. Nikmati preview gratis setiap edisi atau dapatkan akses
            penuh dengan berlangganan. Bacaan berkualitas untuk inspirasi Anda.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#koleksi">
              <button className="px-8 py-3 bg-primary text-primary-foreground rounded-md font-medium hover:bg-primary/90 transition-colors w-full sm:w-auto shadow-lg shadow-primary/20">
                Jelajahi Koleksi
              </button>
            </a>
            <a href="#tentang">
              <button className="px-8 py-3 border-2 border-primary text-primary rounded-md font-medium hover:bg-primary/10 transition-colors w-full sm:w-auto">
                Tentang J One TV
              </button>
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
