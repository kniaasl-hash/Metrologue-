"use client"

import { ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import Link from "next/link"

export function Header() {
  const { items } = useCart()
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="font-serif text-lg font-bold leading-none text-primary">Metrologue</span>
            <span className="text-xs text-muted-foreground leading-none">E-Magazine</span>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" className="text-sm hover:text-primary transition-colors">
            Beranda
          </Link>
          <Link href="#koleksi" className="text-sm hover:text-primary transition-colors">
            Koleksi
          </Link>
          <Link href="#tentang" className="text-sm hover:text-primary transition-colors">
            Tentang Kami
          </Link>
        </nav>

        <Link href="/keranjang">
          <Button variant="outline" size="sm" className="relative bg-transparent border-primary/30 hover:bg-primary/10">
            <ShoppingCart className="h-4 w-4 text-primary" />
            {itemCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {itemCount}
              </span>
            )}
          </Button>
        </Link>
      </div>
    </header>
  )
}
