export function Footer() {
  return (
    <footer className="border-t border-border py-12 bg-muted/20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-foreground rounded-sm" />
              <span className="font-serif text-lg font-semibold">Majalah Digital</span>
            </div>
            <p className="text-sm text-muted-foreground">Platform terpercaya untuk majalah digital berkualitas</p>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Kategori</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Teknologi
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Gaya Hidup
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Bisnis
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Pendidikan
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Perusahaan</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#tentang" className="hover:text-foreground transition-colors">
                  Tentang Kami
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Kontak
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Karir
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Kebijakan Privasi
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Syarat & Ketentuan
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 Majalah Digital Indonesia. Semua hak dilindungi.</p>
        </div>
      </div>
    </footer>
  )
}
