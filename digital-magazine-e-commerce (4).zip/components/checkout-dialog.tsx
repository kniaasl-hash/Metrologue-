"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface CheckoutDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CheckoutDialog({ open, onOpenChange }: CheckoutDialogProps) {
  const { getTotal, clearCart } = useCart()
  const { toast } = useToast()
  const router = useRouter()
  const [metodePembayaran, setMetodePembayaran] = useState("transfer")
  const [processing, setProcessing] = useState(false)

  const handleCheckout = async () => {
    setProcessing(true)

    // Simulasi proses pembayaran
    await new Promise((resolve) => setTimeout(resolve, 1500))

    clearCart()
    setProcessing(false)
    onOpenChange(false)

    toast({
      title: "Pembayaran Berhasil!",
      description: "Terima kasih atas pembelian Anda. Majalah dapat diakses di email Anda.",
    })

    router.push("/")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Checkout</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <h3 className="font-semibold mb-3">Metode Pembayaran</h3>
            <div className="space-y-2">
              <label className="flex items-center gap-3 p-3 border border-border rounded-md cursor-pointer hover:bg-muted/50 transition-colors">
                <input
                  type="radio"
                  name="payment"
                  value="transfer"
                  checked={metodePembayaran === "transfer"}
                  onChange={(e) => setMetodePembayaran(e.target.value)}
                  className="w-4 h-4"
                />
                <div>
                  <div className="font-medium">Transfer Bank</div>
                  <div className="text-sm text-muted-foreground">BCA, Mandiri, BNI</div>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 border border-border rounded-md cursor-pointer hover:bg-muted/50 transition-colors">
                <input
                  type="radio"
                  name="payment"
                  value="ewallet"
                  checked={metodePembayaran === "ewallet"}
                  onChange={(e) => setMetodePembayaran(e.target.value)}
                  className="w-4 h-4"
                />
                <div>
                  <div className="font-medium">E-Wallet</div>
                  <div className="text-sm text-muted-foreground">GoPay, OVO, Dana</div>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 border border-border rounded-md cursor-pointer hover:bg-muted/50 transition-colors">
                <input
                  type="radio"
                  name="payment"
                  value="kartu"
                  checked={metodePembayaran === "kartu"}
                  onChange={(e) => setMetodePembayaran(e.target.value)}
                  className="w-4 h-4"
                />
                <div>
                  <div className="font-medium">Kartu Kredit/Debit</div>
                  <div className="text-sm text-muted-foreground">Visa, Mastercard</div>
                </div>
              </label>
            </div>
          </div>

          <div className="border-t border-border pt-4">
            <div className="flex items-center justify-between mb-4">
              <span className="font-medium">Total Pembayaran</span>
              <span className="text-xl font-bold">Rp {getTotal().toLocaleString("id-ID")}</span>
            </div>

            <Button onClick={handleCheckout} className="w-full" size="lg" disabled={processing}>
              {processing ? "Memproses..." : "Bayar Sekarang"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
