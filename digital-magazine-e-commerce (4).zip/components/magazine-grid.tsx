"use client"

import { useState, useEffect } from "react"
import { MagazineCard } from "@/components/magazine-card"
import { Button } from "@/components/ui/button"
import { Plus, Trash2 } from "lucide-react"
import { AddMagazineDialog } from "@/components/add-magazine-dialog"
import { EditMagazineDialog } from "@/components/edit-magazine-dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export interface Magazine {
  id: string
  nama: string
  judul: string
  kategori: string
  harga: number
  deskripsi: string
  tipe: "gratis" | "berbayar"
  previewPages: number
  totalPages: number
  flipbookUrl?: string
  stok: number
  coverImage?: string
}

const defaultMagazines: Magazine[] = [
  {
    id: "1",
    nama: "TechNow",
    judul: "Masa Depan Kecerdasan Buatan",
    kategori: "Teknologi",
    harga: 49000,
    deskripsi: "Eksplorasi mendalam tentang perkembangan AI dan dampaknya terhadap industri modern",
    tipe: "berbayar",
    previewPages: 5,
    totalPages: 50,
    flipbookUrl: "https://example.com/flipbook/technow-ai",
    stok: 100,
  },
  {
    id: "2",
    nama: "Lifestyle Asia",
    judul: "Tren Gaya Hidup 2024",
    kategori: "Gaya Hidup",
    harga: 0,
    deskripsi: "Panduan lengkap untuk hidup lebih sehat, produktif, dan bermakna",
    tipe: "gratis",
    previewPages: 30,
    totalPages: 30,
    flipbookUrl: "https://example.com/flipbook/lifestyle-asia",
    stok: 999,
  },
  {
    id: "3",
    nama: "Bisnis Today",
    judul: "Strategi Startup Sukses",
    kategori: "Bisnis",
    harga: 59000,
    deskripsi: "Wawasan dari para pendiri startup terkemuka tentang membangun bisnis yang berkelanjutan",
    tipe: "berbayar",
    previewPages: 8,
    totalPages: 65,
    flipbookUrl: "https://example.com/flipbook/bisnis-today",
    stok: 50,
  },
  {
    id: "4",
    nama: "Edukasi Plus",
    judul: "Pembelajaran Digital di Era Modern",
    kategori: "Pendidikan",
    harga: 45000,
    deskripsi: "Metode pembelajaran inovatif untuk meningkatkan efektivitas belajar",
    tipe: "berbayar",
    previewPages: 6,
    totalPages: 45,
    flipbookUrl: "https://example.com/flipbook/edukasi-plus",
    stok: 75,
  },
]

export function MagazineGrid() {
  const [magazines, setMagazines] = useState<Magazine[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editingMagazine, setEditingMagazine] = useState<Magazine | null>(null)

  useEffect(() => {
    const stored = localStorage.getItem("magazines")
    if (stored) {
      setMagazines(JSON.parse(stored))
    }
  }, [])

  const handleAddMagazine = (magazine: Omit<Magazine, "id">) => {
    const newMagazine = {
      ...magazine,
      id: Date.now().toString(),
    }
    console.log(
      "[v0] Adding new magazine:",
      newMagazine.nama,
      "with coverImage:",
      newMagazine.coverImage ? "yes (length: " + newMagazine.coverImage.length + ")" : "no",
    )
    const updated = [...magazines, newMagazine]
    setMagazines(updated)
    localStorage.setItem("magazines", JSON.stringify(updated))
    setDialogOpen(false)
  }

  const handleEditMagazine = (updatedMagazine: Magazine) => {
    console.log(
      "[v0] Updating magazine:",
      updatedMagazine.nama,
      "with coverImage:",
      updatedMagazine.coverImage ? "yes (length: " + updatedMagazine.coverImage.length + ")" : "no",
    )
    const updated = magazines.map((mag) => (mag.id === updatedMagazine.id ? updatedMagazine : mag))
    setMagazines(updated)
    localStorage.setItem("magazines", JSON.stringify(updated))
    setEditDialogOpen(false)
    setEditingMagazine(null)
  }

  const handleDeleteMagazine = (id: string) => {
    const updated = magazines.filter((mag) => mag.id !== id)
    setMagazines(updated)
    localStorage.setItem("magazines", JSON.stringify(updated))
  }

  const handleClearAllMagazines = () => {
    setMagazines([])
    localStorage.setItem("magazines", JSON.stringify([]))
  }

  const handleOpenEdit = (magazine: Magazine) => {
    setEditingMagazine(magazine)
    setEditDialogOpen(true)
  }

  return (
    <section id="koleksi" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-2">Koleksi Majalah</h2>
            <p className="text-muted-foreground">Pilihan terbaik untuk bacaan digital Anda</p>
          </div>
          <div className="flex gap-2">
            {magazines.length > 0 && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <Trash2 className="h-4 w-4" />
                    <span className="hidden sm:inline">Hapus Semua</span>
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Hapus Semua Majalah?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Apakah Anda yakin ingin menghapus semua koleksi majalah? Tindakan ini tidak dapat dibatalkan.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Batal</AlertDialogCancel>
                    <AlertDialogAction onClick={handleClearAllMagazines}>Hapus Semua</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
            <Button onClick={() => setDialogOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Tambah Majalah</span>
            </Button>
          </div>
        </div>

        {magazines.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground mb-4">Belum ada majalah dalam koleksi</p>
            <Button onClick={() => setDialogOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Tambah Majalah Pertama
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {magazines.map((magazine) => (
              <MagazineCard
                key={magazine.id}
                magazine={magazine}
                onEdit={handleOpenEdit}
                onDelete={handleDeleteMagazine}
              />
            ))}
          </div>
        )}
      </div>

      <AddMagazineDialog open={dialogOpen} onOpenChange={setDialogOpen} onAdd={handleAddMagazine} />
      {editingMagazine && (
        <EditMagazineDialog
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          magazine={editingMagazine}
          onEdit={handleEditMagazine}
        />
      )}
    </section>
  )
}
