"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ShoppingCart, ExternalLink, Lock } from "lucide-react"
import type { Magazine } from "@/components/magazine-grid"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"

interface PreviewDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  magazine: Magazine
}

export function PreviewDialog({ open, onOpenChange, magazine }: PreviewDialogProps) {
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleBuy = () => {
    addItem(magazine)
    toast({
      title: "Ditambahkan ke keranjang",
      description: `${magazine.nama} berhasil ditambahkan`,
    })
    onOpenChange(false)
  }

  const handleOpenPreview = () => {
    if (magazine.flipbookUrl) {
      window.open(magazine.flipbookUrl, "_blank")
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl">{magazine.nama}</DialogTitle>
          <DialogDescription>{magazine.judul}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Preview info */}
          <div className="bg-muted/30 rounded-lg p-8 min-h-[400px] flex flex-col items-center justify-center border border-border space-y-6">
            <div className="text-center space-y-4 max-w-2xl">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <Lock className="h-8 w-8 text-primary" />
              </div>

              <h3 className="font-serif text-2xl font-bold">{magazine.judul}</h3>

              <p className="text-muted-foreground leading-relaxed">{magazine.deskripsi}</p>

              <div className="bg-background border border-border rounded-lg p-4 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Preview Tersedia:</span>
                  <span className="font-semibold">{magazine.previewPages} halaman pertama</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Total Halaman:</span>
                  <span className="font-semibold">{magazine.totalPages} halaman</span>
                </div>
              </div>

              {magazine.flipbookUrl && (
                <Button onClick={handleOpenPreview} variant="outline" size="lg" className="gap-2 w-full bg-transparent">
                  <ExternalLink className="h-4 w-4" />
                  Buka Preview Terbatas
                </Button>
              )}

              <p className="text-xs text-muted-foreground italic">
                Preview terbatas hanya menampilkan {magazine.previewPages} halaman pertama. Untuk akses penuh, silakan
                lakukan pembelian.
              </p>
            </div>
          </div>

          {/* Purchase CTA for paid magazines */}
          {magazine.tipe === "berbayar" && (
            <div className="border-t border-border pt-4">
              <div className="bg-muted/50 rounded-lg p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold mb-1">Akses Penuh {magazine.totalPages} Halaman</p>
                  <p className="text-sm text-muted-foreground">Dapatkan akses ke semua konten eksklusif</p>
                </div>
                <Button onClick={handleBuy} size="lg" className="gap-2">
                  <ShoppingCart className="h-4 w-4" />
                  Beli Sekarang - Rp {magazine.harga.toLocaleString("id-ID")}
                </Button>
              </div>
            </div>
          )}

          {/* Free magazine access */}
          {magazine.tipe === "gratis" && magazine.flipbookUrl && (
            <div className="border-t border-border pt-4">
              <div className="bg-primary/10 rounded-lg p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold mb-1">Majalah Gratis</p>
                  <p className="text-sm text-muted-foreground">Akses langsung ke semua halaman</p>
                </div>
                <Button onClick={handleOpenPreview} size="lg" className="gap-2">
                  <ExternalLink className="h-4 w-4" />
                  Baca Sekarang
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
