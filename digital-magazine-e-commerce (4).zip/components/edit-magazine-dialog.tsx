"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload } from "lucide-react"
import type { Magazine } from "@/components/magazine-grid"

interface EditMagazineDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  magazine: Magazine
  onEdit: (magazine: Magazine) => void
}

export function EditMagazineDialog({ open, onOpenChange, magazine, onEdit }: EditMagazineDialogProps) {
  const [formData, setFormData] = useState<Magazine>(magazine)
  const [imagePreview, setImagePreview] = useState<string>(magazine.coverImage || "")

  useEffect(() => {
    if (open) {
      setFormData(magazine)
      setImagePreview(magazine.coverImage || "")
      console.log(
        "[v0] Edit dialog opened with magazine:",
        magazine.nama,
        "coverImage:",
        magazine.coverImage ? "exists" : "no image",
      )
    }
  }, [magazine, open])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    console.log("[v0] File selected:", file?.name, file?.type)
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const base64String = reader.result as string
        console.log("[v0] Image converted to base64, length:", base64String.length)
        setFormData({ ...formData, coverImage: base64String })
        setImagePreview(base64String)
      }
      reader.onerror = () => {
        console.error("[v0] Error reading file")
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log(
      "[v0] Saving magazine with coverImage:",
      formData.coverImage ? "Image present (length: " + formData.coverImage.length + ")" : "No image",
    )
    onEdit(formData)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl">Edit Majalah</DialogTitle>
          <DialogDescription>Perbarui informasi majalah di bawah ini</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit-nama">Nama Majalah</Label>
            <Input
              id="edit-nama"
              value={formData.nama}
              onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
              placeholder="Masukkan nama majalah"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-judul">Judul Edisi</Label>
            <Input
              id="edit-judul"
              value={formData.judul}
              onChange={(e) => setFormData({ ...formData, judul: e.target.value })}
              placeholder="Masukkan judul edisi"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-coverImage">Foto Sampul</Label>
            <div className="flex items-center gap-4">
              <Button
                type="button"
                variant="outline"
                className="w-full bg-transparent"
                onClick={() => document.getElementById("edit-coverImage")?.click()}
              >
                <Upload className="w-4 h-4 mr-2" />
                {imagePreview ? "Ganti Foto" : "Upload Foto Sampul"}
              </Button>
              <Input
                id="edit-coverImage"
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>
            {imagePreview && (
              <div className="mt-2 relative w-full h-48 rounded-lg overflow-hidden border">
                <img
                  src={imagePreview || "/placeholder.svg"}
                  alt="Preview sampul"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <p className="text-xs text-muted-foreground">
              Upload foto sampul majalah dari galeri Anda (format: JPG, PNG, dll)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-kategori">Kategori</Label>
            <Select value={formData.kategori} onValueChange={(value) => setFormData({ ...formData, kategori: value })}>
              <SelectTrigger id="edit-kategori">
                <SelectValue placeholder="Pilih kategori" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Teknologi">Teknologi</SelectItem>
                <SelectItem value="Gaya Hidup">Gaya Hidup</SelectItem>
                <SelectItem value="Bisnis">Bisnis</SelectItem>
                <SelectItem value="Pendidikan">Pendidikan</SelectItem>
                <SelectItem value="Kesehatan">Kesehatan</SelectItem>
                <SelectItem value="Olahraga">Olahraga</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-tipe">Tipe Majalah</Label>
            <Select
              value={formData.tipe}
              onValueChange={(value: "gratis" | "berbayar") =>
                setFormData({ ...formData, tipe: value, harga: value === "gratis" ? 0 : formData.harga })
              }
            >
              <SelectTrigger id="edit-tipe">
                <SelectValue placeholder="Pilih tipe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gratis">Gratis</SelectItem>
                <SelectItem value="berbayar">Berbayar</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.tipe === "berbayar" && (
            <div className="space-y-2">
              <Label htmlFor="edit-harga">Harga (Rp)</Label>
              <Input
                id="edit-harga"
                type="number"
                value={formData.harga}
                onChange={(e) => setFormData({ ...formData, harga: Number.parseInt(e.target.value) || 0 })}
                placeholder="Masukkan harga"
                min="0"
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="edit-stok">Stok Edisi</Label>
            <Input
              id="edit-stok"
              type="number"
              value={formData.stok}
              onChange={(e) => setFormData({ ...formData, stok: Number.parseInt(e.target.value) || 0 })}
              placeholder="Masukkan jumlah stok"
              min="0"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-previewPages">Halaman Preview</Label>
              <Input
                id="edit-previewPages"
                type="number"
                value={formData.previewPages}
                onChange={(e) => setFormData({ ...formData, previewPages: Number.parseInt(e.target.value) || 1 })}
                placeholder="Jumlah preview"
                min="1"
                max={formData.totalPages}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-totalPages">Total Halaman</Label>
              <Input
                id="edit-totalPages"
                type="number"
                value={formData.totalPages}
                onChange={(e) => setFormData({ ...formData, totalPages: Number.parseInt(e.target.value) || 1 })}
                placeholder="Total halaman"
                min="1"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-deskripsi">Deskripsi</Label>
            <Textarea
              id="edit-deskripsi"
              value={formData.deskripsi}
              onChange={(e) => setFormData({ ...formData, deskripsi: e.target.value })}
              placeholder="Masukkan deskripsi majalah"
              rows={3}
              required
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Batal
            </Button>
            <Button type="submit">Simpan Perubahan</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
