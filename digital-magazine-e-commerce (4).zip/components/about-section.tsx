"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Pencil } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface CompanyProfile {
  mission: string
  advantages: string[]
  email: string
  phone: string
  address: string
  website: string
}

export function AboutSection() {
  const [profile, setProfile] = useState<CompanyProfile>({
    mission:
      "J One TV hadir sebagai penyedia konten digital terdepan di Indonesia. Melalui Metrologue E-Magazine, kami menghadirkan bacaan berkualitas yang menginspirasi, mendidik, dan menghibur masyarakat Indonesia.",
    advantages: [
      "Preview gratis untuk semua edisi",
      "Konten eksklusif dari J One TV",
      "Akses instan setelah pembelian",
      "Berbagai metode pembayaran",
    ],
    email: "info@jonetv.com",
    phone: "021-12345678",
    address: "Jakarta, Indonesia",
    website: "www.jonetv.com",
  })
  const [editOpen, setEditOpen] = useState(false)
  const [tempProfile, setTempProfile] = useState(profile)

  // Load from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("companyProfile")
    if (saved) {
      setProfile(JSON.parse(saved))
    }
  }, [])

  const handleSave = () => {
    setProfile(tempProfile)
    localStorage.setItem("companyProfile", JSON.stringify(tempProfile))
    setEditOpen(false)
  }

  const handleEditClick = () => {
    setTempProfile(profile)
    setEditOpen(true)
  }

  return (
    <section id="tentang" className="py-16 md:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-center flex-1">Tentang J One TV</h2>
            <Button onClick={handleEditClick} variant="outline" size="sm" className="gap-2 bg-transparent">
              <Pencil className="h-4 w-4" />
              Edit Profil
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-background p-8 rounded-lg border border-border">
              <h3 className="font-semibold text-xl mb-3">Misi Kami</h3>
              <p className="text-muted-foreground leading-relaxed">{profile.mission}</p>
            </div>

            <div className="bg-background p-8 rounded-lg border border-border">
              <h3 className="font-semibold text-xl mb-3">Keunggulan Kami</h3>
              <ul className="space-y-2 text-muted-foreground">
                {profile.advantages.map((item, index) => (
                  <li key={index} className="flex gap-2">
                    <span>•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-background p-8 rounded-lg border border-border">
            <h3 className="font-semibold text-xl mb-4">Hubungi Kami</h3>
            <div className="space-y-2 text-muted-foreground">
              <p>
                <strong className="text-foreground">Email:</strong> {profile.email}
              </p>
              <p>
                <strong className="text-foreground">Telepon:</strong> {profile.phone}
              </p>
              <p>
                <strong className="text-foreground">Alamat:</strong> {profile.address}
              </p>
              <p>
                <strong className="text-foreground">Website:</strong> {profile.website}
              </p>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Edit Profil Perusahaan</DialogTitle>
            <DialogDescription>Perbarui informasi profil J One TV</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="mission">Misi Perusahaan</Label>
              <Textarea
                id="mission"
                value={tempProfile.mission}
                onChange={(e) => setTempProfile({ ...tempProfile, mission: e.target.value })}
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label>Keunggulan (pisahkan dengan baris baru)</Label>
              <Textarea
                value={tempProfile.advantages.join("\n")}
                onChange={(e) => setTempProfile({ ...tempProfile, advantages: e.target.value.split("\n") })}
                rows={4}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  value={tempProfile.email}
                  onChange={(e) => setTempProfile({ ...tempProfile, email: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telepon</Label>
                <Input
                  id="phone"
                  value={tempProfile.phone}
                  onChange={(e) => setTempProfile({ ...tempProfile, phone: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Alamat</Label>
              <Input
                id="address"
                value={tempProfile.address}
                onChange={(e) => setTempProfile({ ...tempProfile, address: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                value={tempProfile.website}
                onChange={(e) => setTempProfile({ ...tempProfile, website: e.target.value })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setEditOpen(false)}>
              Batal
            </Button>
            <Button onClick={handleSave}>Simpan Perubahan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  )
}
