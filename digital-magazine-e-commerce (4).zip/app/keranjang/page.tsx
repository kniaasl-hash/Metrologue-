"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useCart } from "@/hooks/use-cart"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Minus, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import { CheckoutDialog } from "@/components/checkout-dialog"
import { useState } from "react"

export default function CartPage() {
  const { items, updateQuantity, removeItem, getTotal } = useCart()
  const [checkoutOpen, setCheckoutOpen] = useState(false)

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="font-serif text-3xl font-bold mb-4">Keranjang Belanja</h1>
            <p className="text-muted-foreground mb-8">Keranjang Anda masih kosong</p>
            <Link href="/">
              <Button>Kembali Berbelanja</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="font-serif text-3xl font-bold mb-8">Keranjang Belanja</h1>

          <div className="space-y-4 mb-8">
            {items.map((item) => (
              <Card key={item.id} className="p-4">
                <div className="flex gap-4">
                  <div className="w-20 h-28 bg-muted rounded overflow-hidden flex-shrink-0">
                    <img
                      src={`https://placehold.co/80x112?text=${encodeURIComponent(item.nama)}`}
                      alt={`Cover ${item.nama}`}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold mb-1">{item.nama}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{item.judul}</p>
                    <p className="font-semibold">Rp {item.harga.toLocaleString("id-ID")}</p>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeItem(item.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>

                    <div className="flex items-center gap-2 border border-border rounded-md">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="h-8 w-8 p-0"
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-8 text-center text-sm">{item.quantity}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="h-8 w-8 p-0"
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <span className="text-lg font-semibold">Total</span>
              <span className="text-2xl font-bold">Rp {getTotal().toLocaleString("id-ID")}</span>
            </div>
            <Button onClick={() => setCheckoutOpen(true)} className="w-full" size="lg">
              Lanjutkan ke Pembayaran
            </Button>
          </Card>
        </div>
      </main>
      <Footer />

      <CheckoutDialog open={checkoutOpen} onOpenChange={setCheckoutOpen} />
    </div>
  )
}
