"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { Magazine } from "@/components/magazine-grid"

interface CartItem extends Magazine {
  quantity: number
}

interface CartStore {
  items: CartItem[]
  addItem: (magazine: Magazine) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  getTotal: () => number
}

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],

      addItem: (magazine) => {
        const items = get().items
        const existingItem = items.find((item) => item.id === magazine.id)

        if (existingItem) {
          set({
            items: items.map((item) => (item.id === magazine.id ? { ...item, quantity: item.quantity + 1 } : item)),
          })
        } else {
          set({ items: [...items, { ...magazine, quantity: 1 }] })
        }
      },

      removeItem: (id) => {
        set({ items: get().items.filter((item) => item.id !== id) })
      },

      updateQuantity: (id, quantity) => {
        if (quantity <= 0) {
          get().removeItem(id)
        } else {
          set({
            items: get().items.map((item) => (item.id === id ? { ...item, quantity } : item)),
          })
        }
      },

      clearCart: () => set({ items: [] }),

      getTotal: () => {
        return get().items.reduce((total, item) => total + item.harga * item.quantity, 0)
      },
    }),
    {
      name: "cart-storage",
    },
  ),
)
